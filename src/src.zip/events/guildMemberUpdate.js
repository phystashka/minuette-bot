export const name = 'guildMemberUpdate';
export const once = false;

export const execute = async (oldMember, newMember) => {
  try {

  } catch (error) {
    console.error(`Error handling guildMemberUpdate event:`, error.message);
  }
}; 