import dotenv from 'dotenv';
import { GatewayIntentBits, Partials } from 'discord.js';

dotenv.config();

export const config = {
  token: process.env.TOKEN,
  clientId: process.env.CLIENT_ID,
  ownerId: process.env.OWNER_ID,
  
  allowedTesters: [
    process.env.OWNER_ID,
    '1217948886317138064'
  ],
  
  ai: {
    key: process.env.AI_API_KEY || 'malixkeyforhisbotlumixkeyauf2x',
    baseUrl: process.env.AI_BASE_URL || 'https://lkapi.plexai.xyz/v1',
    model: process.env.AI_MODEL || 'gpt-3.5-turbo-0125' 
  },
  
  api: {
    enabled: process.env.API_ENABLED === 'true' || false,
    port: parseInt(process.env.API_PORT) || 3001,
    secret: process.env.API_SECRET || 'default__key',
    allowedOrigins: process.env.API_ALLOWED_ORIGINS ? process.env.API_ALLOWED_ORIGINS.split(',') : ['http://localhost:3000']
  },
  
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildVoiceStates,
    GatewayIntentBits.GuildInvites,
    GatewayIntentBits.GuildMessageReactions,
    GatewayIntentBits.DirectMessages
  ],
  
  partials: [
    Partials.Message,
    Partials.Channel,
    Partials.Reaction,
    Partials.User
  ],
  
  colors: {
    primary: 0x7CC9F9,
    success: 0x57F287,
    error: 0xED4245,
    warning: 0xFEE75C,
    info: 0x7CC9F9
  }
}; 