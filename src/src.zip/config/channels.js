export const channels = {
  logs: {
    commands: "1378500764040695912"
  }
}; 